#Primer
#Tipos de datos
x = 150
type(x)
x = 13.5
type(x)
x = "hola"
type(x)
x = False
type(x)
x = "46"
type(x)
#Segundo
#Operaciones con datos
a = 10
b = 4
c= a + b
print(c)

b/ a
b // a
b % a

16789 % 10
5 / 2
5 % 2

#Tercer
"buen" + "dia"
a = "buen"
b = "dia"
c = a + " " + b
print(c)
len(c)
c[0]
c[1 + 1]
c[len(c)-1]

#Cuarto
4 < 10
"hola" == "adios"
5 <= 5
"a" < "b"
"casa" < "cosa"
edad = 20
edad > 18