edad = 16
print(edad > 10 and edad < 20)
print(edad > 20 and edad < 30)
print(edad > 20 or edad < 30)
es_cliente = True
print(type(es_cliente))
print(es_cliente and edad > 18)
es_cliente
print(not es_cliente)
