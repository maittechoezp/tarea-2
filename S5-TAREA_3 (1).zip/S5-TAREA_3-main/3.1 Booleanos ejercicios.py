#¿Qué resultado (True / False) dan las siguientes operaciones?
a = not True
b = not(1 + 2!=3)
x =(len("jugar")>5) and (len("jugar")<10)
d = "alto" [2] == "t" and x
e = 842913 % 3 and len("cafe") == 3
f = 0!= 0 or "a" < "y"
g = True or int("50") >= 50
edad = 20
h = not(x) or edad % 2 == 0
es_cliente = False
i = not(es_cliente and not (edad < 18))
print(i)