#¿Qué guardan las variables luego de cada operacion?
n = 167 / 10
n = 167 // 10
n = 167 % 10
letra = "a"
saludo = "hola"+letra
C = saludo[0]
C = saludo[1+3]
L = len(saludo)
C = saludo[len(saludo)-1]
menor = "a" < "b"
D = 1!=1
D = "cinta" >= "canto"
c = "z" + "a" + "paz" [0]
x = c[0] == "z"
print(saludo)

#Cuáles de las siguientes operaciones arrojan error?
a = 11 - ( 4 % 2 + 10 )
b = "30" + 2
c = "30" + "2"
d = "hola" [len("hola")]
e = len(124)
f = "hola" [len("fin")]
g = "hola" [11 - ( 4 % 2 + 10 )]
h = int("4")
i = int(4)
j = int("z")
k = int("4.")
l = 4 < "f"
#m = "palabra" = "rama"
n = "palabra" == "rama"

print(a)
