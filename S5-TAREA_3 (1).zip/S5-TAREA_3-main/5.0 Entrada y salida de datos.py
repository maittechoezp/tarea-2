print(45+10)
print("hola")
print("hola",1)
a = 60
print("hola",a)

input("Ingresa tu edad: ")

edad = input("Ingresa tu edad: ")
print(edad)
print(type(edad))

edad = input("Ingresa tu edad: ")
edad = int(edad)
print(type(edad))
print(edad > 18)



