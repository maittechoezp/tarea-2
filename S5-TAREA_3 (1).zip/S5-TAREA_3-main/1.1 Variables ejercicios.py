#Primer
X = 46
X = 15
x = 30
print(X)
#Segundo
X = 10 * 2
X-=5
print(X)
#Tercer
X = 10 - 2
10 + 2
print(X)
#Cuarto
Y = 3 * (4 + 2)
X = Y + 2
Z = 5
X = Y - Z
print(X)
#Quinto
X = 25
X + 10
print(X)
#Sexto
X = 3
Y = X + 6
X = Y - 1
print(X)
